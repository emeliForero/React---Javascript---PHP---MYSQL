<?php
    $conexion = mysqli_connect("127.0.0.1", "root", "", "bd_litografia");
    mysqli_set_charset($conexion, "utf8");
?> 